package contracts

import (
	"encoding/json"
	"fmt"
	"time"

	"github.com/hyperledger/fabric-chaincode-go/shim"
	"github.com/hyperledger/fabric-contract-api-go/contractapi"
)

// DrugContract contract for managing CRUD for Drug
type DrugContract struct {
	contractapi.Contract
}

type PaginatedQueryResult struct {
	Records             []*Drug `json:"records"`
	FetchedRecordsCount int32  `json:"fetchedRecordsCount"`
	Bookmark            string `json:"bookmark"`
}

type HistoryQueryResult struct {
	Record    *Drug   `json:"record"`
	TxId      string `json:"txId"`
	Timestamp string `json:"timestamp"`
	IsDelete  bool   `json:"isDelete"`
}

type Drug struct {
	AssetType         string `json:"AssetType"`
	DrugId             string `json:"DrugId"`
	DateOfExiry             string `json:"DateOfExiry"`
	DateOfManufacture string `json:"DateOfManufacture"`
	OwnedBy           string `json:"OwnedBy"`
	Make              string `json:"Make"`
	Model             string `json:"Model"`
	Status            string `json:"Status"`
}

type EventData struct{
	Type string
	Model string
}

// DrugExists returns true when asset with given ID exists in world state
func (c *DrugContract) DrugExists(ctx contractapi.TransactionContextInterface, drugID string) (bool, error) {
	data, err := ctx.GetStub().GetState(drugID)

	if err != nil {
		return false, fmt.Errorf("failed to read from world state: %v", err)

	}
	return data != nil, nil
}

// CreateDrug creates a new instance of Drug
func (c *DrugContract) CreateDrug(ctx contractapi.TransactionContextInterface, drugID string, make string, model string, dateofexpiry string, manufacturerName string, dateOfManufacture string) (string, error) {
	clientOrgID, err := ctx.GetClientIdentity().GetMSPID()
	if err != nil {
		return "", err
	}

	// if clientOrgID == "Org1MSP" {
	// if clientOrgID == "manufacturer-pharmaceutical-com" {
	if clientOrgID == "ManufacturerMSP" {
		exists, err := c.DrugExists(ctx, drugID)
		if err != nil {
			return "", fmt.Errorf("could not read from world state. %s", err)
		} else if exists {
			return "", fmt.Errorf("the asset %s already exists", drugID)
		}

		drug := Drug{
			AssetType:         "drug",
			DrugId:             drugID,
			DateOfExiry:             dateofexpiry,
			DateOfManufacture: dateOfManufacture,
			Make:              make,
			Model:             model,
			OwnedBy:           manufacturerName,
			Status:            "In Factory",
		}
		fmt.Println("Create drug data ======= ", drug)
		bytes, _ := json.Marshal(drug)

		err = ctx.GetStub().PutState(drugID, bytes)
		if err != nil {
			return "", err
		} else {
			addDrugEventData := EventData{
				Type: "Drug creation",
				Model: model,
			}
			eventDataByte, _ := json.Marshal(addDrugEventData)
			ctx.GetStub().SetEvent("CreateDrug",eventDataByte)

			return fmt.Sprintf("successfully added drug %v", drugID), nil
		}

	} else {
		return "", fmt.Errorf("user under following MSPID: %v can't perform this action", clientOrgID)
	}

}

// ReadDrug retrieves an instance of Drug from the world state
func (c *DrugContract) ReadDrug(ctx contractapi.TransactionContextInterface, drugID string) (*Drug, error) {
	exists, err := c.DrugExists(ctx, drugID)
	if err != nil {
		return nil, fmt.Errorf("could not read from world state. %s", err)
	} else if !exists {
		return nil, fmt.Errorf("the asset %s does not exist", drugID)
	}

	bytes, _ := ctx.GetStub().GetState(drugID)

	drug := new(Drug)

	err = json.Unmarshal(bytes, &drug)

	if err != nil {
		return nil, fmt.Errorf("could not unmarshal world state data to type Drug")
	}

	return drug, nil
}

// DeleteDrug removes the instance of Drug from the world state
func (c *DrugContract) DeleteDrug(ctx contractapi.TransactionContextInterface, drugID string) (string, error) {

	clientOrgID, err := ctx.GetClientIdentity().GetMSPID()
	if err != nil {
		return "", err
	}
	// if clientOrgID == "Org1MSP" {
	// if clientOrgID == "manufacturer-pharmaceutical-com" {
	if clientOrgID == "ManufacturerMSP" {
		exists, err := c.DrugExists(ctx, drugID)
		if err != nil {
			return "", fmt.Errorf("could not read from world state. %s", err)
		} else if !exists {
			return "", fmt.Errorf("the asset %s does not exist", drugID)
		}

		err = ctx.GetStub().DelState(drugID)
		if err != nil {
			return "", err
		} else {
			return fmt.Sprintf("drug with id %v is deleted from the world state.", drugID), nil
		}

	} else {
		return "", fmt.Errorf("user under following MSP:%v cannot able to perform this action", clientOrgID)
	}
}

// GetDrugsByRange gives a range of asset details based on a start key and end key
func (c *DrugContract) GetDrugsByRange(ctx contractapi.TransactionContextInterface, startKey, endKey string) ([]*Drug, error) {
	resultsIterator, err := ctx.GetStub().GetStateByRange(startKey, endKey)
	if err != nil {
		return nil, err
	}
	defer resultsIterator.Close()

	return drugResultIteratorFunction(resultsIterator)
}

func (c *DrugContract) GetDrugHistory(ctx contractapi.TransactionContextInterface, drugID string) ([]*HistoryQueryResult, error) {

	resultsIterator, err := ctx.GetStub().GetHistoryForKey(drugID)
	if err != nil {
		return nil, err
	}
	defer resultsIterator.Close()

	var records []*HistoryQueryResult
	for resultsIterator.HasNext() {
		response, err := resultsIterator.Next()
		if err != nil {
			return nil, err
		}

		var drug Drug
		if len(response.Value) > 0 {
			err = json.Unmarshal(response.Value, &drug)
			if err != nil {
				return nil, err
			}
		} else {
			drug = Drug{
				DrugId: drugID,
			}
		}

		timestamp := response.Timestamp.AsTime()

		formattedTime := timestamp.Format(time.RFC1123)

		record := HistoryQueryResult{
			TxId:      response.TxId,
			Timestamp: formattedTime,
			Record:    &drug,
			IsDelete:  response.IsDelete,
		}
		records = append(records, &record)
	}

	return records, nil
}

func (c *DrugContract) GetAllDrugs(ctx contractapi.TransactionContextInterface) ([]*Drug, error) {

	queryString := `{"selector":{"AssetType":"drug"}, "sort":[{ "DrugId": "desc"}]}`

	resultsIterator, err := ctx.GetStub().GetQueryResult(queryString)
	if err != nil {
		return nil, err
	}
	defer resultsIterator.Close()
	return drugResultIteratorFunction(resultsIterator)
}

func (c *DrugContract) GetDrugsWithPagination(ctx contractapi.TransactionContextInterface, pageSize int32, bookmark string) (*PaginatedQueryResult, error) {
	queryString := `{"selector":{"AssetType":"drug"}}`
	resultsIterator, responseMetadata, err := ctx.GetStub().GetQueryResultWithPagination(queryString, pageSize, bookmark)
	if err != nil {
		return nil, err
	}
	defer resultsIterator.Close()

	drugs, err := drugResultIteratorFunction(resultsIterator)
	if err != nil {
		return nil, err
	}

	return &PaginatedQueryResult{
		Records:             drugs,
		FetchedRecordsCount: responseMetadata.FetchedRecordsCount,
		Bookmark:            responseMetadata.Bookmark,
	}, nil
}

// Iterator function
func drugResultIteratorFunction(resultsIterator shim.StateQueryIteratorInterface) ([]*Drug, error) {
	var drugs []*Drug
	for resultsIterator.HasNext() {
		queryResult, err := resultsIterator.Next()
		if err != nil {
			return nil, err
		}
		var drug Drug
		err = json.Unmarshal(queryResult.Value, &drug)
		if err != nil {
			return nil, err
		}
		drugs = append(drugs, &drug)
	}

	return drugs, nil
}

// GetMatchingOrders get matching orders for drug from the orders
func (c *DrugContract) GetMatchingOrders(ctx contractapi.TransactionContextInterface, drugID string) ([]*Order, error) {
	exists, err := c.DrugExists(ctx, drugID)
	if err != nil {
		return nil, fmt.Errorf("could not read from world state. %s", err)
	} else if !exists {
		return nil, fmt.Errorf("the asset %s does not exist", drugID)
	}

	drug, err := c.ReadDrug(ctx, drugID)
	if err != nil {
		return nil, fmt.Errorf("error reading drug %v", err)
	}
	queryString := fmt.Sprintf(`{"selector":{"assetType":"Order","make":"%s", "model": "%s", "dateofexpiry":"%s"}}`, drug.Make, drug.Model, drug.DateOfExiry)
	resultsIterator, err := ctx.GetStub().GetPrivateDataQueryResult(collectionName, queryString)

	if err != nil {
		return nil, err
	}
	defer resultsIterator.Close()

	return OrderResultIteratorFunction(resultsIterator)

}

// MatchOrder matches drug with matching order
func (c *DrugContract) MatchOrder(ctx contractapi.TransactionContextInterface, drugID string, orderID string) (string, error) {

	bytes, err := ctx.GetStub().GetPrivateData(collectionName, orderID)
	if err != nil {
		fmt.Println("Could not get ptivate data")
	}
	order := new(Order)

	err = json.Unmarshal(bytes, order)

	if err != nil {
		fmt.Println("Could not get ptivate data")
	}

	if err != nil {
		return "", err
	}

	drug, err := c.ReadDrug(ctx, drugID)
	if err != nil {
		return "", err
	}

	if drug.Make == order.Make && drug.DateOfExiry == order.DateOfExiry && drug.Model == order.Model {
		drug.OwnedBy = order.DistributorName
		drug.Status = "assigned to a distributor"
		bytes, _ := json.Marshal(drug)
		ctx.GetStub().DelPrivateData(collectionName, orderID)
		err = ctx.GetStub().PutState(drugID, bytes)
		if err != nil {
			return "", err
		} else {
			return fmt.Sprintf("Deleted order %v and Assigned %v to %v", orderID, drug.DrugId, order.DistributorName), nil
		}
	} else {
		return "", fmt.Errorf("order is not matching")
	}
}

// RegisterDrug register drug to the buyer
func (c *DrugContract) RegisterDrug(ctx contractapi.TransactionContextInterface, drugID string, ownerName string, registrationNumber string) (string, error) {
	clientOrgID, err := ctx.GetClientIdentity().GetMSPID()
	if err != nil {
		return "", err
	}

	// if clientOrgID == "Org3MSP" {
	// if clientOrgID == "pharmacist-pharmaceutical-com" {
	if clientOrgID == "PharmacistMSP" {

		exists, err := c.DrugExists(ctx, drugID)
		if err != nil {
			return "", fmt.Errorf("could not read from world state. %s", err)
		}
		if exists {
			drug, _ := c.ReadDrug(ctx, drugID)
			drug.Status = fmt.Sprintf("Registered to  %v with plate number %v", ownerName, registrationNumber)
			drug.OwnedBy = ownerName

			bytes, _ := json.Marshal(drug)
			err = ctx.GetStub().PutState(drugID, bytes)
			if err != nil {
				return "", err
			} else {
				return fmt.Sprintf("Drug %v successfully registered to %v", drugID, ownerName), nil
			}

		} else {
			return "", fmt.Errorf("drug %v does not exist", drugID)
		}

	} else {
		return "", fmt.Errorf("user under following MSPID: %v cannot able to perform this action", clientOrgID)
	}

}
