package main

import "fmt"

func main() {

	// use this functions to evaluate and submit txns
	// try calling these functions

	result := submitTxnFn(
		"manufacturer",
		"pharmaceuticalchannel",
		"KBA-Pharmaceutical",
		"DrugContract",
		"invoke",
		make(map[string][]byte),
		"CreateDrug",
		"Drug1",
		"Cipla",
		"nicip",
		"25/11/2023",
		"hydf1",
		"25/10/2023",
	)

	// privateData := map[string][]byte{
	// 	"make":       []byte("Maruti"),
	// 	"model":      []byte("Alto"),
	// 	"dateofexpiry":      []byte("Red"),
	// 	"distributorName": []byte("Popular"),
	// }

	// result := submitTxnFn("distributor", "pharmaceuticalchannel", "KBA-Pharmaceutical", "OrderContract", "private", privateData, "CreateOrder", "ORD-03")
	// result := submitTxnFn("distributor", "pharmaceuticalchannel", "KBA-Pharmaceutical", "OrderContract", "query", make(map[string][]byte), "ReadOrder", "ORD-03")
	// result := submitTxnFn("manufacturer", "pharmaceuticalchannel", "KBA-Pharmaceutical", "DrugContract", "query", make(map[string][]byte), "GetAllDrugs")
	// result := submitTxnFn("manufacturer", "pharmaceuticalchannel", "KBA-Pharmaceutical", "OrderContract", "query", make(map[string][]byte), "GetAllOrders")
	// result := submitTxnFn("manufacturer", "pharmaceuticalchannel", "KBA-Pharmaceutical", "DrugContract", "query", make(map[string][]byte), "GetMatchingOrders", "Drug-06")
	// result := submitTxnFn("manufacturer", "pharmaceuticalchannel", "KBA-Pharmaceutical", "DrugContract", "invoke", make(map[string][]byte), "MatchOrder", "Drug-06", "ORD-01")
	// result := submitTxnFn("pharmacist", "pharmaceuticalchannel", "KBA-Pharmaceutical", "DrugContract", "invoke", make(map[string][]byte), "RegisterDrug", "Drug-06", "Dani", "KL-01-CD-01")
	fmt.Println(result)
}
