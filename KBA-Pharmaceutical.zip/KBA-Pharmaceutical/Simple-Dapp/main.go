package main

import (
	"fmt"
	"net/http"
	"sync"

	"github.com/gin-gonic/gin"
)

type Drug struct {
	DrugId        string `json:"drugId"`
	Make         string `json:"make"`
	Model        string `json:"model"`
	DateOfExiry        string `json:"dateofexpiry"`
	Date         string `json:"dateOfManufacture"`
	Manufacturer string `json:"manufacturerName"`
}

func main() {
	router := gin.Default()

	var wg sync.WaitGroup
	wg.Add(1)
	go ChaincodeEventListener("manufacturer", "pharmaceuticalchannel", "KBA-Pharmaceutical", &wg)

	router.Static("/public", "./public")
	router.LoadHTMLGlob("templates/*")

	router.GET("/", func(ctx *gin.Context) {
		ctx.HTML(http.StatusOK, "index.html", gin.H{
			"title": "Auto App",
		})
	})

	router.POST("/api/drug", func(ctx *gin.Context) {
		var req Drug
		if err := ctx.BindJSON(&req); err != nil {
			ctx.JSON(http.StatusBadRequest, gin.H{"message": "Bad request"})
			return
		}

		fmt.Printf("drug response %s", req)
		emptyPvtData := make(map[string][]byte)
		submitTxnFn("manufacturer", "pharmaceuticalchannel", "KBA-Pharmaceutical", "DrugContract", "invoke", emptyPvtData, "CreateDrug", req.DrugId, req.Make, req.Model, req.DateOfExiry, req.Manufacturer, req.Date)

		ctx.JSON(http.StatusOK, req)
	})

	router.GET("/api/drug/:id", func(ctx *gin.Context) {
		drugId := ctx.Param("id")

		emptyPvtData := make(map[string][]byte)
		result := submitTxnFn("manufacturer", "pharmaceuticalchannel", "KBA-Pharmaceutical", "DrugContract", "query", emptyPvtData, "ReadDrug", drugId)

		ctx.JSON(http.StatusOK, gin.H{"data": result})
	})


	router.GET("/get-event", func(ctx *gin.Context) {
		result := getEvents()
		fmt.Println("result:", result)

		ctx.JSON(http.StatusOK, gin.H{"drugEvent": result})
	})

	router.Run("0.0.0.0:3000")
}