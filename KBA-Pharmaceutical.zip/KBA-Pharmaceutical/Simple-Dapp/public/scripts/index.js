const addData = async (event) => {
    event.preventDefault();

    const drugId = document.getElementById("drugId").value;
    const make = document.getElementById("make").value;
    const model = document.getElementById("model").value;
    const dateofexpiry = document.getElementById("dateofexpiry").value;
    const dateOfManufacture = document.getElementById("dateOfManufacture").value;
    const manufacturerName = document.getElementById("manufacturerName").value;


    const drugData = {
        drugId: drugId,
        make: make,
        model: model,
        dateofexpiry: dateofexpiry,
        dateOfManufacture: dateOfManufacture,
        manufacturerName: manufacturerName,
    };


    if (
        drugId.length == 0 ||
        make.length == 0 ||
        model.length == 0 ||
        dateofexpiry.length == 0 ||
        dateOfManufacture.length == 0 ||
        manufacturerName.length == 0
    ) {
        alert("Please enter the data properly.");
    } else {
        try {
            const response = await fetch("/api/drug", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(drugData),
            });
            console.log("RESPONSE: ", response)
            const data = await response.json()
            console.log("DATA: ", data);
            return alert("Drug Created");
        } catch (err) {
            alert("Error");
            console.log(err);
        }
    }
};

const readData = async (event) => {
    event.preventDefault();
    const drugId = document.getElementById("drugIdInput").value;

    if (drugId.length == 0) {
        alert("Please enter a valid ID.");
    } else {
        try {
            const response = await fetch(`/api/drug/${drugId}`);
            let responseData = await response.json();
            console.log("sadsdsdd", responseData);
            alert(JSON.stringify(responseData));
        } catch (err) {
            alert("Error");
            console.log(err);
        }
    }
};
