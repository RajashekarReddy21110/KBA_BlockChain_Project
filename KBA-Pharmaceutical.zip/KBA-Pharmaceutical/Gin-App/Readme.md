```
go get github.com/gin-gonic/gin
```
```
curl -X POST http://localhost:8080/store -H "Content-Type: application/json" -d '{"mykey":"myvalue"}'
```
```
curl http://localhost:8080/retrieve/mykey
```