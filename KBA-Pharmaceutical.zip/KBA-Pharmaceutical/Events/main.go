package main

func main() {

	// blockEventListener("manufacturer", "pharmaceuticalchannel")
	chaincodeEventListener("manufacturer", "pharmaceuticalchannel", "KBA-Pharmaceutical")
	// pvtBlockEventListener("manufacturer", "pharmaceuticalchannel")

}